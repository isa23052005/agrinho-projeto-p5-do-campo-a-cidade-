let trees = [];
let fireParticles = [];
let smokeParticles = [];
let burningHouse;
let houseTimer = 0;
let houseVisible = true;

function setup() {
  createCanvas(800, 600);
  
  // Iniciar a zona rural (floresta pegando fogo)
  for (let i = 0; i < 15; i++) {  // Mais árvores e mais espalhadas
    trees.push(new Tree(random(50, width - 50), random(100, height - 200)));
  }

  for (let i = 0; i < 100; i++) {
    fireParticles.push(new FireParticle(random(width), height, random(2, 5)));
  }

  // Criar a casa na floresta
  burningHouse = new BurningHouse(500, 300);

  // Definir botão para mudar entre a floresta
  
}

function draw() {
  // Cenário da Floresta
  drawForest();
  
  // Verificar se a casa deve desaparecer
  if (millis() - houseTimer > 10000 && houseVisible) {
    houseVisible = false; // Esconde a casa após 10 segundos
  }
}

// Função para desenhar o cenário da Floresta
function drawForest() {
  background(255, 102, 0); // Céu laranja de incêndio

  // Chão queimado
  fill(60, 60, 60);
  noStroke();
  rect(0, height - 100, width, 100);

  // Efeitos de fogo no chão
  for (let fire of fireParticles) {
    fire.update();
    fire.display();
  }

  // Desenhando árvores em chamas
  for (let tree of trees) {
    tree.display();
    tree.burn();
  }

  // Fumaça
  for (let smoke of smokeParticles) {
    smoke.update();
    smoke.display();
  }

  // Casa em chamas (apenas visível antes de 10 segundos)
  if (houseVisible) {
    burningHouse.display();
  }
}

// Função para alternar entre os cenários (aqui pode ser removido já que não terá mais a transição)
function toggleScene() {
  // Este código foi removido, pois não há mais a transição entre os cenários.
}

// Classe para criar árvores na floresta
class Tree {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.burning = false;
    this.fireIntensity = random(0.1, 1);
  }

  display() {
    // Tronco detalhado
    fill(139, 69, 19); // Cor do tronco
    noStroke();
    rect(this.x - 10, this.y, 20, random(50, 100)); // Tronco com variação de altura

    // Detalhes do tronco
    fill(100, 50, 25);
    for (let i = 0; i < 5; i++) {
      line(this.x - 5, this.y + i * 20, this.x + 5, this.y + i * 20 + random(-5, 5)); // Variação de linha no tronco
    }

    // Folhagem da árvore (copa)
    fill(34, 139, 34); // Cor da copa
    ellipse(this.x, this.y - 30, random(50, 80), random(50, 80));  // Copa variada em tamanho
    ellipse(this.x - 20, this.y - 40, random(40, 60), random(40, 60));  // Copa extra
    ellipse(this.x + 20, this.y - 40, random(40, 60), random(40, 60));  // Copa extra

    if (this.burning) {
      this.burn();
    }
  }

  burn() {
    let fireSize = map(this.fireIntensity, 0.1, 1, 10, 40);
    fill(255, random(100, 200), 0, 150);
    ellipse(this.x, this.y - 35, fireSize, fireSize);

    this.fireIntensity += 0.01;
    if (this.fireIntensity > 1) this.fireIntensity = 1;

    if (this.fireIntensity > 0.5) {
      smokeParticles.push(new Smoke(this.x, this.y - 50));
    }
  }

  ignite() {
    this.burning = true;
  }
}

// Classe para partículas de fogo
class FireParticle {
  constructor(x, y, speed) {
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.size = random(3, 5);
    this.alpha = 255;
  }

  update() {
    this.y -= this.speed;
    this.alpha -= 2;
    if (this.alpha <= 0) {
      this.alpha = 0;
      this.y = height; // Volta para o chão
    }
  }

  display() {
    fill(255, random(100, 200), 0, this.alpha);
    noStroke();
    ellipse(this.x, this.y, this.size, this.size);
  }
}

// Classe para fumaça
class Smoke {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = random(30, 60);
    this.alpha = 200;
  }

  update() {
    this.y -= 1;
    this.alpha -= 1;
    if (this.alpha <= 0) {
      this.alpha = 0;
      this.y = height / 2;
    }
  }

  display() {
    fill(200, 200, 200, this.alpha);
    noStroke();
    ellipse(this.x, this.y, this.size, this.size);
  }
}

// Classe para desenhar a casa em chamas
class BurningHouse {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }

  display() {
    fill(139, 69, 19);
    rect(this.x, this.y, 60, 60); // Corpo da casa
    
    fill(255, 69, 0, 150);
    triangle(this.x, this.y, this.x + 30, this.y - 30, this.x + 60, this.y); // Telhado em chamas

    fill(255, 140, 0, 150);
    rect(this.x + 20, this.y + 20, 20, 40); // Janela em chamas
  }
}

